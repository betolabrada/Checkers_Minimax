#------------------------------------------------------------------------------------------------------------------
#	Decodificación de movimientos del móvil con técnicas de aprendizaje supervisado
#	Integrantes:
#		Alan González
#		Hyuntae Kim
#		Alberto Labrada
#------------------------------------------------------------------------------------------------------------------

#------------------------------------------------------------------------------------------------------------------
from sklearn import datasets
from sklearn import svm
from sklearn.model_selection import KFold
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
import matplotlib.pyplot as plt
import numpy as np
import sys
from scipy import stats
from scipy import signal

#------------------------------------------------------------------------------------------------------------------
#   Class Clasificador
#	* Entrenta todos los clasificadores y obtiene el precision, recall y accuracy para cada una de las 4 clases
#------------------------------------------------------------------------------------------------------------------
class Clasificador:
	def __init__(self, clf):
		self.clf = clf
		self.acc = 0
		self.recall = {}
		self.precision = {}

	def train(self, kf, x, y):
		for train_index, test_index in kf.split(x):

            # Training phase
			x_train = x[train_index, :]
			y_train = y[train_index]

			self.clf.fit(x_train, y_train)

            # Test phase
			x_test = x[test_index, :]
			y_test = y[test_index]

			y_pred = self.clf.predict(x_test)

            # Calculate confusion matrix and model performance
			cm = confusion_matrix(y_test, y_pred)
			acc_i = (cm[0,0]+cm[1,1]+cm[2,2]+cm[3,3])/len(y_test)
			for i in range(4):
				if not i in self.recall:
					self.recall[i] = 0
				if not i in self.precision:
					self.precision[i] = 0

				self.recall[i] += cm[i,i] / np.sum(cm, axis=1)[i]
				self.precision[i] += cm[i,i] / np.sum(cm, axis=0)[i]

			self.acc += acc_i

	def results(self, kf_splits=5):
		res = ''
		res += 'Accuracy: ' + str(self.acc / kf_splits) + '\n'
		res += 'Recall:\n'
		for i in range(4):
			res += '  Class ' + str(i + 1) + ': ' + str(self.recall[i] / kf_splits) + '\n'
		res += 'Precision:\n'
		for i in range(4):
			res += '  Class ' + str(i + 1) + ': ' + str(self.precision[i] / kf_splits) + '\n'

		return res

#------------------------------------------------------------------------------------------------------------------
#   Manejo de archivos
#------------------------------------------------------------------------------------------------------------------
# Archivo de señales
data = np.loadtxt(sys.argv[1])
# Archivo de ventanas
exp_data = np.loadtxt(sys.argv[2], dtype='int')

fs = 15															# Velocidad de muestreo
window_size = int(sys.argv[3] if len(sys.argv) > 3 else 5)		# Input de usuario
nsignals = data.shape[1]										# Numero de señales

trials = {}
# Append windows per movement
for step in exp_data:
	for index in range(step[1], step[2], window_size):
		# print(step[0], ' - ', index, ' - ', index + window_size - 1)

		if not step[0] in trials:
			trials[step[0]] = []

		trials[step[0]].append([index, index + window_size - 1])

mean_values = {}
std_values = {}
kurtosis_values = {}
skewness_values = {}
psd_values = {}
psd_freqs = []

output = []

for mov in trials:
	#print('Movimiento', mov)

	mean_values[mov] = []
	std_values[mov] = []
	kurtosis_values[mov] = []
	skewness_values[mov] = []
	psd_values[mov] = []

	for win in trials[mov]:
		# print('   Window', win)
		# Temporary values
		output_v = []
		output_v.append(mov)
		mean_v = []
		std_v = []
		kurtosis_v = []
		skewness_v = []
		psd_v = []
		for s in range(nsignals):
			# Foreach signal 
			sig = data[win[0] : win[1] + 1, s]
			mean = np.average(sig)
			std = np.std(sig)
			kur = stats.kurtosis(sig)
			skew = stats.skew(sig)

			mean_v.append(mean)
			std_v.append(std)
			kurtosis_v.append(kur)
			skewness_v.append(skew)

			freqs, psd = signal.periodogram(sig, fs, 'hamming', scaling='spectrum')
			psd_v.append(psd)
			psd_freqs = freqs
			# print(psd_freqs)

		
		mean_values[mov].append(mean_v)
		std_values[mov].append(std_v)
		kurtosis_values[mov].append(kurtosis_v)
		skewness_values[mov].append(skewness_v)
		psd_values[mov].append(psd_v)

		output_v.extend(mean_v)
		output_v.extend(std_v)
		output_v.extend(kurtosis_v)
		output_v.extend(skewness_v)
		output.append(output_v)

#------------------------------------------------------------------------------------------------------------------
#   Procesamiento de archivo para su posterior clasificación
#------------------------------------------------------------------------------------------------------------------
# Sort array by first column
output = np.array(output)
output = output[np.argsort(output[:, 0])]
# np.savetxt('moves_data.txt', output, fmt='%1.4g')
x = []
y = []
for result in output:
	y.append(result[0])
	x.append([i for i in result[1:]])

x = np.array(x)
y = np.array(y)

# 5-fold cross-validation
kf = KFold(n_splits=5, shuffle = True)

# SVM Lineal
clf = Clasificador(svm.SVC(kernel='linear'))
clf.train(kf, x, y)
print('RESULTADOS SVM LINEAL')
print(clf.results())

# SVM Base radial
clf = Clasificador(svm.SVC(kernel='rbf'))
clf.train(kf, x, y)
print('RESULTADOS SVM BASE RADIAL')
print(clf.results())

# K-NN
clf = Clasificador(KNeighborsClassifier(n_neighbors=3))
clf.train(kf, x, y)
print('RESULTADOS K-NN')
print(clf.results())

# ARBOL DE DECISION
clf = Clasificador(DecisionTreeClassifier())
clf.train(kf, x, y)
print('RESULTADOS ARBOL DE DECISION')
print(clf.results())

# SLP
clf = Clasificador(MLPClassifier(hidden_layer_sizes=(10), random_state=1, max_iter=10000))
clf.train(kf, x, y)
print('RESULTADOS RED PERCEPTRÓN UNA CAPA')
print(clf.results())

# MLP
clf = Clasificador(MLPClassifier(hidden_layer_sizes=(10, 10), random_state=1, max_iter=10000))
clf.train(kf, x, y)
print('RESULTADOS RED PERCEPTRÓN MULTI CAPA')
print(clf.results())

#------------------------------------------------------------------------------------------------------------------
#   End of file
#------------------------------------------------------------------------------------------------------------------